#pragma once

#include <signal.h>

/* SIGNALS */
#define SIGIRQ1 SIGUSR1   // End of time-slice
#define SIGIRQ2 SIGUSR2   // I/O operation
