#include <sys/sem.h>

void sem_down(int semid, int semnum);
void sem_up(int semid, int semnum);