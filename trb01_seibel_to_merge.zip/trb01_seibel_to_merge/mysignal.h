#pragma once

#include <signal.h>

/* SIGNALS */
#define SIGIRQ0 SIGUSR1   // End of time-slice.
#define SIGIRQ1 SIGUSR2   // I/O operation.
